(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_889678b3._.js",
  "static/chunks/node_modules_e4e9e3f5._.js"
],
    source: "dynamic"
});
