module.exports=[33127,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_catalog_%5Bid%5D_page_actions_a077e2e3.js.map