var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cars/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__035b5a9e._.js")
R.c("server/chunks/_next-internal_server_app_api_cars_route_actions_7042c64f.js")
R.m(75037)
module.exports=R.m(75037).exports
