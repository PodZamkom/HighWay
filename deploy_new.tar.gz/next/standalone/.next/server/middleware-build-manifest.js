globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/465f799faf41e6df.js",
    "static/chunks/806bdb8e4a6a9b95.js",
    "static/chunks/e1140cc73d7c6ca2.js",
    "static/chunks/d702a24e2b6c48fa.js",
    "static/chunks/turbopack-10358343ca7588f4.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];